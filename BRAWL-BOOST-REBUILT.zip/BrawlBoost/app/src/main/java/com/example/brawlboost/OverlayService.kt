package com.example.brawlboost

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlay: TextView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (overlay == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val refreshHz = try {
                windowManager?.defaultDisplay?.refreshRate?.toInt() ?: 0
            } catch (_: Exception) { 0 }

            overlay = TextView(this).apply {
                text = "BRAWL BOOST • $refreshHz Hz\n画面Hz（実FPSではありません）\nタップで閉じる"
                textSize = 12f
                setTextColor(Color.WHITE)
                setBackgroundColor(0xDD10243D.toInt())
                setPadding(18, 12, 18, 12)
                setOnClickListener { stopSelf() }
            }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = 16
                y = 120
            }
            try {
                windowManager?.addView(overlay, params)
            } catch (_: Exception) {
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try {
            overlay?.let { windowManager?.removeView(it) }
        } catch (_: Exception) { }
        overlay = null
        windowManager = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
