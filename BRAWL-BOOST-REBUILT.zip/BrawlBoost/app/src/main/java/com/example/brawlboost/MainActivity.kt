package com.example.brawlboost

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val background = 0xFF0A111F.toInt()
    private val panel = 0xFF162439.toInt()
    private val accent = 0xFF26A4FF.toInt()
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background
        window.navigationBarColor = background
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) render()
    }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(background) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
        }
        scroll.addView(content)
        setContentView(scroll)

        addText("BRAWL BOOST", 28, 0xFFFFFFFF.toInt(), true)
        addText("PIXEL 10 • GAME COMPANION", 12, accent, true)
        addSpace(20)

        val battery = getSystemService(BATTERY_SERVICE) as BatteryManager
        val percent = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val hz = try { display?.refreshRate?.roundToInt() ?: 0 } catch (_: Exception) { 0 }
        val temp = readBatteryTemperatureC()

        addMetric("DISPLAY", if (hz > 0) "$hz Hz" else "--", "画面のリフレッシュレート")
        addSpace(8)
        addMetric("BATTERY", if (percent in 0..100) "$percent%" else "--", "バッテリー残量")
        addSpace(8)
        addMetric("BATTERY TEMPERATURE", temp?.let { String.format("%.1f°C", it) } ?: "--",
            "バッテリー温度。端末全体の温度ではありません")
        addSpace(20)

        addText("LIVE MONITOR", 18, 0xFFFFFFFF.toInt(), true)
        addText(
            "Androidの通常アプリは、他のゲーム内部の実FPSを直接読み取れません。" +
                "このアプリでは画面Hz、バッテリー残量、取得可能なバッテリー温度を表示します。",
            14, 0xFFD5DCE8.toInt()
        )
        addSpace(10)
        addButton("フローティング表示を開始") { startOverlay() }
        addButton("画面・リフレッシュレート設定") {
            openSettingsOrFallback("android.settings.DISPLAY_SETTINGS")
        }
        addSpace(18)

        addText("PRE-GAME CHECKLIST", 18, 0xFFFFFFFF.toInt(), true)
        listOf(
            "省電力モードをオフにする（必要な場合）",
            "画面の滑らかさを優先に設定する",
            "本体が熱いときは冷めるまで休ませる",
            "充電しながらの長時間プレイを避ける",
            "ブロスタとAndroidを最新状態にする"
        ).forEach { addText("✓  $it", 14, 0xFFFFFFFF.toInt()) }

        addSpace(10)
        addButton("バッテリー設定を開く") {
            openSettingsOrFallback("android.settings.BATTERY_SAVER_SETTINGS")
        }
        addButton("BRAWL BOOSTのアプリ情報") {
            openSettingsOrFallback(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            )
        }
        addSpace(18)
        addText("IMPORTANT", 12, accent, true)
        addText(
            "このアプリはゲームのFPSを強制変更したり、CPU/GPUを強制高速化したりしません。" +
                "オーバーレイに表示するのは実FPSではなく画面リフレッシュレートです。",
            12, 0xFFD5DCE8.toInt()
        )
    }

    private fun readBatteryTemperatureC(): Float? {
        return try {
            val batteryIntent = registerReceiver(
                null,
                android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            ) ?: return null
            val raw = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
            if (raw >= 0) raw / 10f else null
        } catch (_: Exception) {
            null
        }
    }

    private fun addText(value: String, size: Int, color: Int, bold: Boolean = false) {
        content.addView(TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        })
    }

    private fun addMetric(title: String, value: String, description: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(panel)
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 11f
            setTextColor(accent)
        })
        box.addView(TextView(this).apply {
            text = value
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = description
            textSize = 11f
            setTextColor(0xFFD5DCE8.toInt())
        })
        content.addView(box, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun addButton(label: String, action: () -> Unit) {
        content.addView(Button(this).apply {
            text = label
            setOnClickListener { action() }
        }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun addSpace(height: Int) {
        content.addView(View(this), ViewGroup.LayoutParams(1, height))
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } else {
            startService(Intent(this, OverlayService::class.java))
        }
    }

    private fun openSettingsOrFallback(action: String, data: Uri? = null) {
        try {
            val intent = Intent(action)
            if (data != null) intent.data = data
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}
