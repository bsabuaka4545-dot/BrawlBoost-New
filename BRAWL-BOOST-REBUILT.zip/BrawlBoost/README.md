# BRAWL BOOST

Android companion app for checking display refresh rate, battery level and battery temperature, plus safe pre-game settings shortcuts.

## Build
- JDK 17
- Android SDK Platform 35
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21

From this directory:
`gradle :app:assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

Note: Android apps cannot ordinarily read another game's internal FPS. The overlay shows display refresh rate, not measured game FPS. It does not force CPU/GPU performance or terminate other apps.
